﻿using System;
namespace Problem_1.Harvesting_Fields
{
    public class Startup
    {
        public static void Main(string[] args)
        {
           Console.WriteLine(new HarvestingFieldsTest().Run());
        }
    }
}
