﻿[SoftUni("Ventsi")]
public class StartUp
{[SoftUni("Goshko")]
    static void Main(string[] args)
    {
        var tracker = new Tracker();
        tracker.PrintMethodsByAuthor();
    }
}

