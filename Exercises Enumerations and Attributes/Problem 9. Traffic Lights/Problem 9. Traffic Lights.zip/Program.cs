﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Problem_9.Traffic_Lights.Controllers;

namespace Problem_9.Traffic_Lights
{
    class Program
    {
        static void Main(string[] args)
        {
            new Engine().Run();
        }
    }
}
