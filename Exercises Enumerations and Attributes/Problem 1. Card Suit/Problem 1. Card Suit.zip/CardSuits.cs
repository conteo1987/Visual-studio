﻿namespace Problem_1.Card_Suit
{
    public enum CardSuits
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades
    }
}
