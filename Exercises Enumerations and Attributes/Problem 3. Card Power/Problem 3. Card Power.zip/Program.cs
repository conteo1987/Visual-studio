﻿using Problem_3.Card_Power.Controler;

namespace Problem_3.Card_Power
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //new CardPower().Run(); // Problem 3. Card Power and Problem 4. Card ToString()
            //new CardCompareTo().Run(); // Problem 5. Card CompareTo()
            //new CustomEnumAttribute().Run(); // Problem 6. Custom Enum Attribute
            //new DeckOfCards().Run(); // Problem 7. Deck of Cards
            new CardGame().Run(); // Problem 8. Card Game
        }
    }
}
