﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Generic_Box
{
    public class Program
    {
        public static void Main(string[] args)
        {
            SolutionManager.GenericCountMethodDoubles();
        }

    }
}
