﻿using Custom_List.Controlers;

namespace Custom_List
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var engine = new Engine();
            engine.Run();
        }
    }
}
